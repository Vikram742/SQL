use kaggle;
select * from supermarket;
desc supermarket;
#change Date data type from text to date
update supermarket set Date = str_to_date(Date, "%d-%m-%Y");
alter table supermarket modify column Date date;
alter table supermarket modify column Time time;

# Total Transactions
#1. Overall Transactions
select count(*) as total_transactions
from supermarket
;

#2. Monthly Transactions
select monthname(Date) as Month, count(*) as No_of_Transactions
from supermarket
group by monthname(Date)
order by field(monthname (Date),'January','February','March');

#3 Monthly Transactions (MOM % Change) & total_transactions_pct
with cte as
(select monthname(Date) as Month, count(*) as Current_Month_Transactions,
lag(count(*)) over(order by field(monthname (Date),'January','February','March')) as Prev_Month_Transactions
from supermarket
group by monthname(Date)
order by field(monthname (Date),'January','February','March'))
select *, round((Current_Month_Transactions - Prev_Month_Transactions) / Prev_Month_Transactions *100,2) as MOM_Pct_Change,
round((Current_Month_Transactions)*100 / (select sum(Current_Month_Transactions) from cte),2) as total_transactions_pct
from cte;

#4.Weekly Transactions
select weekofyear(Date) as Week_No, count(*) as No_of_Transactions
from supermarket
group by weekofyear(Date)
order by weekofyear(Date);

#5.Weekly Transactions (WOW % Change)
with cte as 
(select weekofyear(Date) as Week_No, count(*) as Current_Week_Transactions,
lag(count(*)) over (order by weekofyear(Date)) as Prev_Week_Transactions
from supermarket
group by weekofyear(Date)
order by weekofyear(Date))
select *, round((Current_Week_Transactions - Prev_Week_Transactions)/ Prev_Week_Transactions * 100,2) as WOW_Pct_Change
from cte;

#6.Total Sales
select round(sum(Total),0) as Total_Sales
from supermarket;

#7.Monthly Sales & MOM pct_change & % of total_sales
with cte as
(select monthname(Date) as month, round(sum(Total),0) as current_month_sales,
lag(round(sum(Total),0)) over (order by field(monthname(Date),"January","February","March")) as prev_month_sales
from supermarket
group by monthname(Date)
order by field(monthname(Date),"January","February","March"))
select *, round((current_month_sales - prev_month_sales) / prev_month_sales *100,2) as MOM_Pct_Change,
round((current_month_sales)*100 / (select sum(current_month_sales) from cte),2) as total_sales_pct
from cte
group by month;

#8. Weekly Sales & WOW_pct change in sales
with cte as
(select weekofyear(Date) as Week_No, round(sum(Total),0) as Current_Week_Sales,
round(lag(sum(Total)) over (order by weekofyear(Date)),0) as Prev_Week_Sales
from supermarket
group by weekofyear(Date)
order by weekofyear(Date))
select *, round((Current_Week_Sales - Prev_Week_Sales) /  Prev_Week_Sales *100,2) as WOW_change_pct
from cte;

### I need to create a new table as I want to add a new column called Day which will contain the days of the week

create table supermarket_2 as 
select *, dayname(Date) as Day
from supermarket;

## I need to create a new table as I want to add a new column called Week_Day which will contain unique records "Weekday" and "Weekend" 
create table supermarket_3 
select *, case when Day in ("Saturday","Sunday") then "Weekend" 
else "Weekday" end as Week_Day
from supermarket_2;

#9. Total transactions for each day and % of total
select Day, count(*) as total_transactions, 
round(count(*) / (select count(*) from supermarket_3),2)*100 as pct_total
from supermarket_3
group by Day
order by field(Day,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");

#10. Total transactions for Day of week and % of total
select Week_Day, count(*) as total_transactions,
count(*) / (select count(*) from supermarket_3)*100 as pct_total
from supermarket_3
group by Week_Day;

#11. Total Sales for each day and % of total
select Day, round(sum(Total),0) as total_sales,
round(sum(Total)/ (select sum(Total) from supermarket_3)*100,2) as pct_total
from supermarket_3
group by Day
order by field(Day,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");

#12.Total transactions for Day of week and % of total
select Week_Day, round(sum(Total)) as total_sales,
round(sum(Total) / (select sum(Total) from supermarket_3)*100,2) as pct_total
from supermarket_3
group by Week_Day;

create table supermarket_4 as
select *, 
case when Time between "10:00:00" and "12:00:00" then "Morning"
     when Time between "12:01:00" and "16:00:00" then "Afternoon"
     when Time between "16:01:00" and "19:00:00" then "Evening"
     else "Night" end as Time_of_Day
from supermarket_3;

#13. Sales across different times of the day & pct of total
select Time_of_Day, round(sum(Total),0) as total_sales,
round(sum(Total) / (select sum(Total) from supermarket_4)*100,2) as pct_total
from supermarket_4
group by Time_of_Day
order by field(Time_of_Day,"Morning","Afternoon","Evening","Night");		

#14. Transactions across different times of the day & pct of total
select Time_of_Day, round(count(*)) as total_transactions,
round(count(*) / (select count(*) from supermarket_4)*100,2) as pct_total
from supermarket_4
group by Time_of_Day
order by field(Time_of_Day,"Morning","Afternoon","Evening","Night");		

#15. Customer Type Count
alter table supermarket_4 change `Customer type` `Customer_Type` varchar(20);		
select Customer_Type, round(count(*)) as Count,
round(count(*) / (select count(*) from supermarket_4)*100,2) as pct_total
from supermarket_4
group by Customer_Type;																			

#16. Break up of Customer Type as per Gender
with cte as
(select Gender, 
	   sum(case when Customer_Type = 'Member' then 1 else 0  end) as 'Member',
       sum(case when Customer_Type = 'Normal' then 1 else 0 end)  as 'Normal'  
            from supermarket_4
            group by Gender)
 select *, round(sum(Member) / (select sum(Member) from cte)*100,2) as Member_gender_pct,
 round(sum(Normal) / (select sum(Normal) from cte)*100,2) as Normal_gender_pct
 from cte
 group by Gender;
            
 #17. Spend members vs normal
 select Customer_Type, round(sum(Total),0) as Total_Spend,
round(sum(Total) / (select sum(Total) from supermarket_4)*100,2) as pct_total
 from supermarket_4
 group by Customer_Type;
 
 #18. spend customer type vs product line
with cte as 
(select Product_Line,
round(sum(case when Customer_Type = 'Member' then Total end),0) as 'Member',
round(sum(case when Customer_Type = 'Normal' then Total end),0) as 'Normal'
from supermarket_4
group by Product_Line)
select *, round(sum(Member) / (select sum(Member) from cte)*100,2) as Member_spendcategory_pct,
round(sum(Normal)/ (select sum(Normal) from cte)*100,2) as Normal_spendcategory_pct
from cte
group by Product_Line ;

#19. Shoppping days for customer type
with cte as
(select Day, sum(case when Customer_Type = "Member" then 1 else 0 end) as Member,
             sum(case when Customer_Type = "Normal" then 1 else 0 end) as Normal
from supermarket_4
group by Day)
select *, round(sum(Member) / (select sum(Member) from cte)*100,2) as member_pct_transaction,
round(sum(Normal) / (select sum(Normal) from cte)*100,2) as normal_pct_transaction
from cte
group by Day
order by field(Day,"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday");

#20. Gender split 
select Gender, count(*) as total_users
from supermarket_4
group by Gender;

#21. Total spend via Gender Type
select Gender, round(sum(Total),0) as total_spend,
round(sum(Total) / (select sum(Total) from supermarket_4)*100,2) as pct_total
from supermarket_4
group by Gender;

#22. Product Line spend via Gender Type
with cte as 
(select Product_Line,
round(sum(case when Gender = 'Male' then Total end),0) as 'Males_Sales',
round(sum(case when Gender = 'Female' then Total end),0) as 'Female_Sales'
from supermarket_4
group by Product_Line)
select *, round(sum(Males_Sales) / (select sum(Males_Sales) from cte)*100,2) as Males_spendcategory_pct,
round(sum(Female_Sales)/ (select sum(Female_Sales) from cte)*100,2) as Females_spendcategory_pct
from cte
group by Product_Line ;

#23. Time of day shopping for Gender
with cte as 
(select Time_of_Day,
sum(case when Gender = 'Male' then 1 else 0 end) as 'MTransactions',
sum(case when Gender = 'Female' then 1 else 0 end) as 'FTransactions'
from supermarket_4
group by Time_of_Day)
select *, round(sum(MTransactions) / (select sum(Mtransactions) from cte)*100,2) as MTransactions_pct,
round(sum(FTransactions)/ (select sum(FTransactions) from cte)*100,2) as FTransactions_pct
from cte
group by Time_of_Day
order by field(Time_of_Day,'Morning','Afternoon','Evening','Night') ;

#24. Product Line Sales and pct_of_total
select Product_Line, round(sum(Total),0) as Total_Sales,
round(sum(Total) / (select sum(Total) from supermarket_4)*100,2) as pct_total_sales
from supermarket_4
group by Product_Line
order by round(sum(Total),0) desc;

#25. Product Line Qty Sold and pct_of_total
select Product_Line, sum(Quantity) as total_quantity_sold,
round(sum(Quantity) / (select sum(Quantity) from supermarket_4)*100,2) as pct_total_Qty_sold
from supermarket_4
group by Product_Line
order by sum(Quantity) desc;

#26.Monthly spend and MOM% change for product line
with cte as
(select Product_line,monthname(Date) as month, round(sum(Total),0) as current_month_sales,
round(lag(sum(Total)) over (partition by Product_line order by field(monthname(Date),'January','February','March')),0) as prev_month_sales
from supermarket_4
group by Product_line,monthname(Date)
order by Product_line,field(monthname(Date),'January','February','March'))
select *, round((current_month_sales - prev_month_sales) / prev_month_sales*100,2) as MOM_pct_change
from cte;

#27. Payment Preference
select Payment, count(*) as total_transactions,
round(count(*) / (select count(*) from supermarket_4)*100,2) as total_pct_transactions,
round(sum(Total),0) as Total_spend,
round(sum(Total) / (select sum(Total) from supermarket_4) *100,2) as total_pct_spend
from supermarket_4
group by Payment;

#28. Payment Preference via Gender
with cte as 
(select Payment, 
round(sum(case when Gender = 'Male' then Total end),0) as Male_Spend,
round(sum(case when Gender = 'Female' then Total end),0) as Female_Spend
from supermarket_4
group by Payment)
select *, round((Male_Spend)/ ((Male_Spend) + (Female_Spend))*100,2) as Male_spend_pct_payment ,
round((Female_Spend)/ ((Male_Spend) + (Female_Spend))*100,2) as Female_spend_pct_payment
from cte
group by Payment;

# 29. Total Transactions & Spend via Branch
select Branch, count(*) as total_transactions,
round(count(*) / (select count(*) from supermarket_4)*100,2) as transactions_pct_total,
round(sum(Total),0) as total_sales,
round(sum(Total) / (select sum(Total) from supermarket_4)*100,2) as sales_pct_total
from supermarket_4
group by Branch
order by Branch;

# 30. Product Line sales via Branch
with cte as
(select Product_line,
round(sum(case when Branch = 'A' then Total end),0) as Branch_A_sales,
round(sum(case when Branch = 'B' then Total end),0) as Branch_B_sales,
round(sum(case when Branch = 'C' then Total end),0) as Branch_C_sales
from supermarket_4
group by Product_line)
select *, round(Branch_A_sales / (Branch_A_sales+Branch_B_sales+Branch_C_sales) *100,2) as Branch_A_pct_sales,
round(Branch_B_sales / (Branch_A_sales+Branch_B_sales+Branch_C_sales) *100,2) as Branch_B_pct_sales,
round(Branch_C_sales / (Branch_A_sales+Branch_B_sales+Branch_C_sales) *100,2) as Branch_C_pct_sales 
from cte
group by Product_line ;


