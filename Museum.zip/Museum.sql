use techtfqinterviewquestions;

-- 1. How many paintings have an asking price of more than their regular price? 
select count(*) 
from product_size
where sale_price > regular_price;

-- 2. Identify the paintings whose asking price is less than 50% of its regular price
select *, round(regular_price/2,1) as discounted_price
from product_size
having sale_price < round(regular_price/2,1);

-- 3. Which canvas size costs the most?
select a.label from
(select c.size_id, c.label, p.sale_price, 
rank() over (order by sale_price desc) as rnk
from canvas_size c
join product_size p
on c.size_id = p.size_id
limit 1) a; 

-- 4. Identify the museums with invalid city information in the given dataset
SELECT name, city
FROM museum
WHERE city REGEXP '^[0-9]';

-- 5. How many museums are open every single day?
select count(*) as no_of_musuems from
(select *, count(*) as days_open
from museum_hours
group by museum_id
order by count(*) desc) a
where a.days_open = 7;

-- 6. Identify the Museums which are open on both Sunday and Monday. Display Museum Name and City
select b.name from
(select *, count(a.museum_id) from
(select m.museum_id,m.name, mh.day
from museum m
join museum_hours mh
on m.museum_id = mh.museum_id
where mh.day in ('Sunday','Monday'))a
group by a.museum_id
having count(a.museum_id) >1) b
order by b.name;

-- 7. Display the country and the city with most no of museums. Output 2 seperate columns to mention the city and country.
-- If there are multiple value, seperate them with comma.
with cte_country as
(select country,count(*), rank() over (order by count(*) desc) as rnk
from museum
group by country),
cte_city as 
(select city,count(*), rank() over (order by count(*) desc) as rnk
from museum
group by city) 
select group_concat(distinct country.country,', ') as country_museum, group_concat(city.city,', ') as city_museum
	from cte_country country
	cross join cte_city city
	where country.rnk = 1
	and city.rnk = 1;



