SELECT * FROM dataset1;
select * from dataset2;

-- Find out the average sex_ratio
select round(avg(Sex_Ratio),0) as avg_sex_ratio
from dataset1;
 -- Average sex ratio is 945 females to 1000 males
 
-- Find the total population state wise
select State, sum(Population) as total_population
from dataset2
group by State
order by total_population desc;

-- Find out the average growth rate of India's Population
select round(avg(Growth)*100,2) 
as avg_growth_pct 
from dataset1;
-- 19.27% has the population grown from the previous census 

-- Find out the states where the population growth has been higher than the overall avg_growth rate
select State, round(avg(Growth),2)*100 as avg_state_growth
from dataset1
group by State 
having avg(Growth) > 
(select round(avg(Growth),2) as avg_growth from 
dataset1)
order by avg_state_growth desc;
-- 16 States were found to have their growth rate higher than the national avg growth rate i.e 19.27

-- Find out the States where the average literacy rate has been lower than the overall literacy rate
select State, round(avg(Literacy),2) as avg_state_literacy
from dataset1
group by State
having avg(Literacy) <
(select round(avg(Literacy),2) as avg_literacy
from dataset1)
order by avg_state_literacy;
-- 11 States were found to have literacy rate lower than the national avg Literacy rate i.e 72.31

-- Find out the number of males and females for each state
select c.State, sum(c.males) as total_males , 
sum(c.females) as total_females from
(select b.District,b.State,b.Sex_Ratio,
b.Population,b.males,
b.Population - b.males as females from
(select *, round(a.Population/(a.SR+1),0) 
as males from
(select d1.District, d1.State, d1.Sex_Ratio,
d2.Population, Sex_Ratio/1000 as SR 
from dataset1 d1
join dataset2 d2 on
d1.District = d2.District) a) b) c
group by c.State;

-- Find out the number of literate and illiterate people for each state
select b.State, sum(b.literate_popn) as total_literate_popn, 
sum(b.illiterate_popn) as total_illiterate_popn from
(select a.District,a.State, a.Population, a.literate_popn, 
a.Population - a.literate_popn as illiterate_popn from
(select d1.District,d1.State,d1.Literacy,d2.Population, 
round((Population*Literacy)/100,0) as literate_popn
from dataset1 d1
join dataset2 d2
on d1.District = d2.District) a) b
group by b.State;

-- Find out the population in the previous census state wise and find the percentage increase or decrease
select b.State,sum(b.Population) as current_popn,
sum(b.previous_popn) as previous_popn,
round((sum(b.Population) - sum(b.previous_popn))
/ sum(previous_popn)*100,2)
as popn_percent_diff from
(select *, round(a.Population/(a.Growth+1),0)
as previous_popn from
(select d1.District,d1.State,d1.Growth,d2.Population
from dataset1 d1
join dataset2 d2
on d1.District = d2.District) a) b
group by b.State;

-- Find the percent change in population vis a vis area per sq km
select * , round((e.current_popn_per_sq_kms - e.previous_popn_per_sq_kms)/
e.previous_popn_per_sq_kms*100,2) as pct_change_pop_per_sq_kms
from (select round(d.total_current_popn/d.total_area_sq_kms,0)
as current_popn_per_sq_kms, 
round(d.total_previous_popn/d.total_area_sq_kms,0)
as previous_popn_per_sq_kms
from (select sum(c.current_popn) as total_current_popn, 
sum(c.previous_popn) as total_previous_popn,
sum(c.total_area_km2) as total_area_sq_kms
from (select b.State,sum(b.Population) as current_popn,
sum(b.previous_popn) as previous_popn,
sum(b.Area_km2) as total_area_km2 from
(select *, round(a.Population/(a.Growth+1),0)
as previous_popn from
(select d1.District,d1.State,d1.Growth,d2.Population,d2.Area_km2
from dataset1 d1
join dataset2 d2
on d1.District = d2.District) a) b 
group by b.State) c ) d ) e;
-- 17.7% . current popn per sq kms is 379 as oppossed to 322 previously

-- Find the top 3 districts within each state with highest literacy rate
select * from
(select District, State, Literacy,
rank() over(partition by State order by Literacy desc) as rnk
from dataset1) a
where a.rnk between 1 and 3;

-- Find the bottom 3 districts within each state with lowest literacy rate
select * from
(select District, State, Literacy, 
rank() over(partition by State order by Literacy) as rnk
from dataset1) a
where a.rnk between 1 and 3;

-- Which state has the highest Area_km2
select a.State,
round(a.state_population/ a.state_area_km2,0)
as popn_density from
(select State, sum(Area_km2) as state_area_km2,
sum(Population) as state_population
from dataset2
group by State) a
order by popn_density desc
limit 1;
-- Chandigarh with a popn density of 9258 per sq km




