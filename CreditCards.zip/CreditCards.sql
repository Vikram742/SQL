Use creditcards;

#1. Which city has spent the highest amount over the years?
select City , sum(Amount) as Total_Amount
from cc
group by City
order by Total_Amount desc
limit 1;

#2. Which card type has the highest amount over the years
select Card_Type , sum(Amount) as Total_Amount
from cc
group by Card_Type
order by Total_Amount desc
limit 1 ;

#3. Which expense type has the highest amount over the years
select Exp_Type, sum(Amount) as Total_Amount
from cc
group by Exp_Type
order by Total_Amount desc
limit 1;

#4. what is the total amount spent between males and females in numbers and percentage
select Gender , sum(Amount) as Total_Amount, sum(Amount)*100/ 
(select (sum(Amount)) as S
from cc) as percent_of_total 
from cc
group by Gender
order by percent_of_total desc;

#5. What is the total amount of spend by females vis a vis Card_Type
select Card_Type, Sum(Amount) as Total_Amount 
from cc
where gender ='F'
group by Card_Type
order by Total_Amount desc;

#6. Which are the top 5 cities which has the highest spend for men?
select City, sum(Amount) as Total_Amount
from cc
group by City
order by Total_Amount desc
limit 5;

#7. List the top 5 cities with the maximum transactions
select City, count(*) as No_of_Transactions
from cc
group by City
order by count(*) desc
limit 5;

#8.Show the month wise spend across the years
select Month, sum(Amount) as Total_Amount
from cc
group by month
order by Amount desc;

#9. Show the total amount spent by men via expense type
select Exp_Type, sum(Amount) as Total_Amount
from cc
where gender = 'M'
group  by Exp_Type
order by Total_Amount desc;

