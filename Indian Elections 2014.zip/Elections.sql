use amitron;
select * from elections;
desc elections;
alter table elections drop column MyUnknownColumn;
#### data cleaning
select * from elections
where Assembly = ' ';
# In state Tamil Nadu for Candidate Hyder Ali S , the Assembly is ' '. We need to check if we can find the Assembly by combing through the data
select * from elections
where State = 'Tamil Nadu';
# We found that Assembly 'Mayiladuthurai' belongs to Candidate Hyder Ali S as he is the 2nd candidate in the Assembly and the entire data is in sequence
# We need to update the table but there is no candidate ID. So either I check whether there is another Hyder Ali.S. If not then I can update it. I can see by party 
# name as well if it has no repetition
select count(*) from elections	
where Party = "Manithaneya Makkal Katchi";
# There is only one count for the party name so I can update using the party name
update elections set Assembly = 'Mayiladuthurai' 
where Party = "Manithaneya Makkal Katchi";
# now lets check whether the Assembly name has been updated
select * from elections	
where Party = "Manithaneya Makkal Katchi";
### Check data types
desc elections;
# Votes is in text. We need to change it to integer
alter table elections modify column Votes int;
# An error has come. I am unable to convert to "int" as there are commas in the values. I need to get rid of these commas
update elections set Votes = replace(Votes,' ,', ' ' );
alter table elections modify Votes int;
# I tried to modify the column but it did not work.So i removed the commas from the csv file and imported the file again and now it is showing as 'int'

############ OBJECTIVE IS TO FOCUS ON PARTY 'BHARATIYA JANTA PARTY' (BJP) 

-- Total states
select count(distinct State)
from elections; 
-- Total 35

-- Vote share of BJP vs rest
select Party, sum(Votes) as total_votes, 
round(sum(Votes)/(select sum(Votes) from elections) * 100,2) as pct_votes
from elections
group by Party
order by sum(Votes) desc;
-- BJP vote share was 31% (highest) followed by Indian National Congress (19.31%)

-- BJP vote share state wise
 select State,
sum(case when Party ="Bharatiya Janata Party" then Votes else 0 end) as BJP_Votes,
sum(Votes) as Total_State_Votes,
round((sum(case when Party ="Bharatiya Janata Party" then Votes else 0 end)/
sum(Votes))*100,2) as pct_votes
from elections
group by State;

-- BJP vote share % (Bottom 5 states)
select State, 
sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) as BJP_Votes,
sum(Votes) as Total_State_Votes,
round(sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end)/
sum(Votes) * 100,2) as pct_votes
from elections
group by State
order by pct_votes 
limit 5;
-- Nagaland (Total Votes : 1038910 (0%), Mizoram (Total Votes: 433201 (0%), Puducherry (Total Votes: 740017 (0%),
-- Lakshwadeep (Total Votes : 43239 (0.43%) , Sikkim (Total Votes: 308967 (2.36%)

-- States where BJP got less than 10% votes
with cte as 
(select State, 
sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) as BJP_Votes,
sum(Votes) as Total_State_Votes,
round(sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end)/
sum(Votes) * 100,2) as pct_votes
from elections
group by State
order by pct_votes) 
select * 
from cte
where pct_votes <= 10;
-- Previous answer + Other 5 are TN(5.47%), Tripura (5.70%), AP (8.46%), Punjab (8.73%), Meghalaya (8.90%)  

-- BJP vote share % (Top 5 states)
select State,
sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) as BJP_Votes,
sum(Votes) as Total_State_Votes,
round(sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) /
sum(Votes) *100,2) as pct_votes
from elections
group by State
order by pct_votes desc
limit 5;
-- Gujarat (59.05%), Uttarakhand (55.32%), Rajasthan (54.94%), MP (54.03%), D&D (53.83%)

-- How many states did BJP get more votes than their total vote share % (i.e.31)
with cte as
(select State,
sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) as BJP_Votes,
sum(Votes),
round(sum(case when Party = "Bharatiya Janata Party" then Votes else 0 end) /
sum(Votes) *100,2) as pct_votes
from elections
group by State)
select count(*)  as no_of_states_above_overall_BJP_Share
from cte 
where pct_votes > 31;
-- 19 states are above the overall BJP vote share and 16 states are below


create table elections_2 as
with cte as
(select *,
dense_rank () over (partition by Assembly order by Votes desc) as rnk 
from elections)
(select State, Assembly, Candidate, Party, Votes,
case when rnk = 1 then 'WON' else 'LOST' 
END AS "ELECTION RESULT" 
from cte
order by State, Assembly,Votes desc);
-- Need to create a duplicate table with the added column "ELECTION RESULT"

select * from elections_2;
desc elections_2;
alter table elections_2
change `Election Result` Result varchar (10);

update elections_2 set Result = 'WON'
where Votes = 307941; 

update elections_2 set Result = 'WON'
where Candidate = "Anurag Singh Thakur";

update elections_2 set Result = 'WON'
where Votes = 320753; 

 
-- How many BJP candidates were fielded in total and how many won
select 
count(*) as total_BJP_Candidates,
sum(case when Result = 'WON' then 1 else 0 end) as BJP_Candidates_Won,
round((sum(case when Result = 'WON' then 1 else 0 end) / count(*) ) * 100,2) 
as pct_winning_candidates 
from elections_2
where Party = "Bharatiya Janata Party";
-- Total BJP Candidates was 428 and 282 won (65.89%)

-- State wise win Strike rate for BJP
select State, count(distinct Assembly) as BJP_contested_seats,
sum(case when Result = "WON" then 1 else 0 end) as BJP_wins,
round(sum(case when Result = "WON" then 1 else 0 end) / count(distinct Assembly) * 100,2) as BJP_pct_win
from elections_2
where Party = "Bharatiya Janata Party"
group by State
order by count(distinct Assembly) desc;
-- UP (91.03%), Bihar (73.33%), MP (93.10%), Gujarat (100%), Rajasthan (100%), Maharashtra (95.83%)
-- The BJP’s seats are extremely regionally concentrated. Six states alone contributed 194 seats (out of the 282 won) to BJP’s kitty, 
-- 68.79 percent of the total number of seats won by the BJP.

-- BJP win strike rate with the above states
with cte as
(select *, count(distinct Assembly) as BJP_contested_seats,
sum(case when Result = "WON" then 1 else 0 end) as BJP_wins,
round(sum(case when Result = "WON" then 1 else 0 end) / count(distinct Assembly) *100,2) as pct_wins
from elections_2
where Party = "Bharatiya Janata Party"
group by State),
revised_cte as
(select State, BJP_contested_seats, BJP_wins,pct_wins
from cte
where State in ("Uttar Pradesh","Bihar", "Madhya Pradesh", "Gujarat", "Rajasthan", "Maharashtra"))
select sum(BJP_contested_seats) as BJP_contested_seats  , sum(BJP_wins) as BJP_seats_won,
round(sum(BJP_wins)/ sum(BJP_contested_seats) * 100,2) as percent_wins
from revised_cte;
-- In the above six states, 212 (seats contested) , 194 (seats won) , 91.51% win 
-- Total Lok Sabha Seats (543), the above contested seats (212) comprise only 39% of the total LK seats

-- BJP win strike rate minus the above states
with cte as
(select *, count(distinct Assembly) as BJP_contested_seats,
sum(case when Result = "WON" then 1 else 0 end) as BJP_wins,
round(sum(case when Result = "WON" then 1 else 0 end) / count(distinct Assembly) *100,2) as pct_wins
from elections_2
where Party = "Bharatiya Janata Party"
group by State),
revised_cte as
(select State, BJP_contested_seats, BJP_wins,pct_wins
from cte
where State not in ("Uttar Pradesh","Bihar", "Madhya Pradesh", "Gujarat", "Rajasthan", "Maharashtra"))
select sum(BJP_contested_seats) as BJP_contested_seats , sum(BJP_wins) as BJP_seats_won,
round(sum(BJP_wins)/ sum(BJP_contested_seats) * 100,2) as percent_wins
from revised_cte;
-- After removing the above states (which made the bulwark of BJP's wins), its strike rate from other states is
-- 216 (seats contested) , 88 (seats won) , 40.74% win 

-- In how many states did the BJP win
with cte as
(select State, Party, count(*) as assemblies_won
from elections_2
where Result = 'WON'
group by State,Party),
revised_cte as 
(select *, rank()over(partition by State order by assemblies_won desc) as rnk
from cte)
select State
from revised_cte
where rnk = 1 and Party = 'Bharatiya Janata Party';
-- 21 states (2 states are tied) 

-- Poor Performing States for the BJP
with cte as 
(select State, count(distinct Assembly) as BJP_contested_seats,
sum(case when Result = "WON" then 1 else 0 end) as BJP_wins,
round(sum(case when Result = "WON" then 1 else 0 end) / count(distinct Assembly) * 100,2) as BJP_pct_win
from elections_2
where Party = "Bharatiya Janata Party"
group by State
order by BJP_pct_win)
select * from cte
where BJP_pct_win < 50 ;
-- 10 such states. But out of these 10, 5 main states where BJP contested (Kerala: 18, 0.00%), (WB : 42, 4.76% win), (AP : 12, 25% win) , 
-- (TN : 9, 11.11% win) , (Odisha : 21, 4.76%)

-- Margin of victory/loss by votes and percentage for each candidate
with cte as
(select *, row_number() over (partition by State,Assembly order by Votes desc) as rn,
max(Votes) over(partition by State,Assembly order by Votes desc) as max_votes,
lead(Votes) over (partition by State,Assembly order by Votes desc) as second_highest_votes,
sum(Votes) over (partition by State,Assembly) as total_assembly_votes
from elections_2),
revised_cte as
(select *, 
case when rn = 1 then (max_votes - second_highest_votes)
else (Votes - max_votes) end as margin_votes
from cte)
select State, Assembly, Candidate, Party, Votes, Result, margin_votes,
round((margin_votes / total_assembly_votes)*100,2) as margin_pct_votes
from revised_cte;

-- Want to create a new table based on the above output for further data analysis
create table elections_3 as
with cte as
(select *, row_number() over (partition by State,Assembly order by Votes desc) as rn,
max(Votes) over(partition by State,Assembly order by Votes desc) as max_votes,
lead(Votes) over (partition by State,Assembly order by Votes desc) as second_highest_votes,
sum(Votes) over (partition by State,Assembly) as total_assembly_votes
from elections_2),
revised_cte as
(select *, 
case when rn = 1 then (max_votes - second_highest_votes)
else (Votes - max_votes) end as margin_votes
from cte)
select State, Assembly, Candidate, Party, Votes, Result, margin_votes,
round((margin_votes / total_assembly_votes)*100,2) as margin_pct_votes
from revised_cte;

select * from elections_3;

-- Top 5 candidates of BJP who had the highest victory margin (numbers)
select Candidate, State, Assembly, margin_votes
from elections_3
where Party = "Bharatiya Janata Party"
order by margin_votes desc
limit 5;
-- Narendra Modi (Gujarat), Vijay Kumar Singh (UP), CR Patil (Gujarat), Ramcharan Bohara (Rajasthan) , Darshana Vikram Jardosh (Gujarat)

--  Top 5 candidates of BJP who had the lowest loss margin (numbers)
select Candidate, State, Assembly, margin_votes
from elections_3
where Party = "Bharatiya Janata Party"
order by margin_votes 
limit 5;
-- Badsha Alam (WB), Sudhindra Chandra Dasgupta (Tripura), MD Alam (WB), Madhusudan Bag (WB), Kamalendu Pahari (WB)

-- Top 5 candidates of BJP who had the highest victory margin (%)
select Candidate, State, Assembly, margin_votes, margin_pct_votes
from elections_3
where Party = "Bharatiya Janata Party"
order by margin_pct_votes desc
limit 5;
-- Darshana Vikram Jardosh (Gujarat), Narendra Modi (Gujarat),  CR Patil (Gujarat), GOPAL CHINAYYA SHETTY (Maharashtra), LK Advani (Gujarat)

--  Top 5 candidates of BJP who had the highest loss margin (%)
select Candidate, State, Assembly, margin_votes, margin_pct_votes
from elections_3
where Party = "Bharatiya Janata Party"
order by margin_pct_votes 
limit 5;
-- Parikshit Debbarma (Tripura), Sudhindra Chandra Dasgupta (Tripura), Mahesh Chandra Mohanty (Odisha), Mushtaq Ahmad Malik (J&K), Nar Bahudar Khatiwada (Sikkim)

