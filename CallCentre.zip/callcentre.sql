Use medium;
SELECT * FROM medium.calls;

set sql_safe_updates = 0;
update calls set csat_score = Null where csat_score = 0;
update calls set call_timestamp = str_to_date(call_timestamp, '%m/%d/%Y');
set sql_safe_updates = 1;

select * 
from calls;

-- Call Centre performance
-- Find out the number of call centres 
select call_center, count(*) as no_of_call_centres
from calls
group by call_center;

-- Find out the average csat_score for each call centre
select call_center, round(avg(csat_score),2) as avg_csat_score
from calls
where csat_score is not null
group by call_center
order by avg_csat_score desc;

-- Find out the number & percentage of calls per call centre
select call_center, count(*), round((count(*) / (select count(*) from calls)) * 100,2) as pct
from calls 
group by call_center 
order by pct desc;

-- find out the count of specific response time for each call centre
select call_center, response_time, count(*) as count
from calls
group by call_center, response_time
order by call_center, count desc; 

-- find out the count and percentage of reasons for calls
select reason, count(*), round((count(*) / (select count(*) from calls)) * 100,2) as pct
from calls
group by reason 
order by pct desc;

-- find out the count and percentage of sentiment for calls
select sentiment, count(*) , round((count(*) / (select count(*) from calls)) * 100,2) as pct
from calls
group by sentiment
order by pct desc;

-- find out the count and percentage of channel 
select channel, count(*), round((count(*) / (select count(*) from calls))*100,2) as pct
from calls
group by channel
order by pct desc;

-- find out the min, max and avg call duration in minutes
select min(call_duration_minutes), max(call_duration_minutes), avg(call_duration_minutes)
from calls;

select sentiment, reason, count(*) as count
from calls
group by sentiment, reason
order by sentiment, count desc;

select *
from calls;